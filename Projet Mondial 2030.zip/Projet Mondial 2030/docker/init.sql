-- =====================================================
-- MONDIAL 2030 EXPERIENCE - Script d'initialisation
-- =====================================================

USE mondial2030;

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    role ENUM('ADMIN', 'FAN') NOT NULL DEFAULT 'FAN',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des matchs
CREATE TABLE IF NOT EXISTS matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_home VARCHAR(100) NOT NULL,
    team_away VARCHAR(100) NOT NULL,
    stadium VARCHAR(150) NOT NULL,
    city VARCHAR(100) NOT NULL,
    match_date DATETIME NOT NULL,
    match_phase VARCHAR(50) DEFAULT 'Phase de groupes'
);

-- Table des zones de stade
CREATE TABLE IF NOT EXISTS zones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    match_id INT NOT NULL,
    category_name ENUM('VIP', 'CAT1', 'CAT2') NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    capacity INT NOT NULL,
    available_seats INT NOT NULL,
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
);

-- Table des tickets
CREATE TABLE IF NOT EXISTS tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    zone_id INT NOT NULL,
    uuid_qrcode VARCHAR(36) NOT NULL UNIQUE,
    status ENUM('ACTIF', 'EN_REVENTE', 'VENDU', 'UTILISE') NOT NULL DEFAULT 'ACTIF',
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resale_price DECIMAL(10,2) DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (zone_id) REFERENCES zones(id) ON DELETE CASCADE
);

-- =====================================================
-- DONNÉES INITIALES
-- =====================================================

-- Administrateur par défaut
INSERT INTO users (username, password, email, role) VALUES
('admin', 'admin123', 'admin@mondial2030.ma', 'ADMIN'),
('fan_maroc', 'fan123', 'supporter@gmail.com', 'FAN');

-- Stades marocains pour le Mondial 2030
INSERT INTO matches (team_home, team_away, stadium, city, match_date, match_phase) VALUES
('Maroc', 'Espagne', 'Grand Stade Hassan II', 'Casablanca', '2030-06-15 21:00:00', 'Phase de groupes'),
('France', 'Brésil', 'Stade Ibn Batouta', 'Tanger', '2030-06-16 18:00:00', 'Phase de groupes'),
('Portugal', 'Argentine', 'Grand Stade de Marrakech', 'Marrakech', '2030-06-17 21:00:00', 'Phase de groupes'),
('Allemagne', 'Angleterre', 'Stade de Fès', 'Fès', '2030-06-18 18:00:00', 'Phase de groupes'),
('Maroc', 'Portugal', 'Grand Stade Hassan II', 'Casablanca', '2030-06-25 21:00:00', 'Huitièmes de finale'),
('Espagne', 'France', 'Stade Ibn Batouta', 'Tanger', '2030-06-26 18:00:00', 'Huitièmes de finale');

-- Zones pour chaque match
-- Match 1: Maroc vs Espagne
INSERT INTO zones (match_id, category_name, price, capacity, available_seats) VALUES
(1, 'VIP', 5000.00, 500, 500),
(1, 'CAT1', 2000.00, 5000, 5000),
(1, 'CAT2', 800.00, 15000, 15000);

-- Match 2: France vs Brésil
INSERT INTO zones (match_id, category_name, price, capacity, available_seats) VALUES
(2, 'VIP', 5000.00, 400, 400),
(2, 'CAT1', 2000.00, 4000, 4000),
(2, 'CAT2', 800.00, 12000, 12000);

-- Match 3: Portugal vs Argentine
INSERT INTO zones (match_id, category_name, price, capacity, available_seats) VALUES
(3, 'VIP', 5000.00, 450, 450),
(3, 'CAT1', 2000.00, 4500, 4500),
(3, 'CAT2', 800.00, 13000, 13000);

-- Match 4: Allemagne vs Angleterre
INSERT INTO zones (match_id, category_name, price, capacity, available_seats) VALUES
(4, 'VIP', 4500.00, 350, 350),
(4, 'CAT1', 1800.00, 3500, 3500),
(4, 'CAT2', 700.00, 10000, 10000);

-- Match 5: Maroc vs Portugal (Huitièmes)
INSERT INTO zones (match_id, category_name, price, capacity, available_seats) VALUES
(5, 'VIP', 8000.00, 500, 500),
(5, 'CAT1', 3500.00, 5000, 5000),
(5, 'CAT2', 1500.00, 15000, 15000);

-- Match 6: Espagne vs France (Huitièmes)
INSERT INTO zones (match_id, category_name, price, capacity, available_seats) VALUES
(6, 'VIP', 8000.00, 400, 400),
(6, 'CAT1', 3500.00, 4000, 4000),
(6, 'CAT2', 1500.00, 12000, 12000);

-- =====================================================
-- NOUVELLES TABLES (Mise à jour v2)
-- =====================================================

-- Table des Stades (Détails logistiques)
CREATE TABLE IF NOT EXISTS Stades (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nom_stade VARCHAR(255),
    ville VARCHAR(100),
    capacite INT,
    distance_centre_ville_km FLOAT,
    photo_url VARCHAR(255)
);

-- Table des Équipes
CREATE TABLE IF NOT EXISTS Equipes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nom_pays VARCHAR(100),
    drapeau_url VARCHAR(255)
);

-- Table des Joueurs
CREATE TABLE IF NOT EXISTS Joueurs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    equipe_id BIGINT,
    nom_complet VARCHAR(255),
    position VARCHAR(50), -- Attaquant, Gardien, etc.
    numero_maillot INT,
    FOREIGN KEY (equipe_id) REFERENCES Equipes(id) ON DELETE CASCADE
);

-- Données initiales pour les Stades
INSERT INTO Stades (nom_stade, ville, capacite, distance_centre_ville_km, photo_url) VALUES
('Grand Stade Hassan II', 'Casablanca', 93000, 25.5, 'stade_casa.jpg'),
('Stade Ibn Batouta', 'Tanger', 65000, 10.2, 'stade_tanger.jpg'),
('Grand Stade de Marrakech', 'Marrakech', 45000, 15.0, 'stade_marrakech.jpg'),
('Stade de Fès', 'Fès', 40000, 8.5, 'stade_fes.jpg');

-- Données initiales pour les Équipes
INSERT INTO Equipes (nom_pays, drapeau_url) VALUES
('Maroc', 'flag_maroc.png'),
('Espagne', 'flag_espagne.png'),
('Portugal', 'flag_portugal.png'),
('France', 'flag_france.png'),
('Brésil', 'flag_bresil.png'),
('Argentine', 'flag_argentine.png'),
('Allemagne', 'flag_allemagne.png'),
('Angleterre', 'flag_angleterre.png');

-- Données initiales pour les Joueurs (Exemple Maroc)
INSERT INTO Joueurs (equipe_id, nom_complet, position, numero_maillot) VALUES
(1, 'Yassine Bounou', 'Gardien', 1),
(1, 'Achraf Hakimi', 'Défenseur', 2),
(1, 'Nayef Aguerd', 'Défenseur', 5),
(1, 'Romain Saïss', 'Défenseur', 6),
(1, 'Sofyan Amrabat', 'Milieu', 4),
(1, 'Azzedine Ounahi', 'Milieu', 8),
(1, 'Hakim Ziyech', 'Attaquant', 7),
(1, 'Youssef En-Nesyri', 'Attaquant', 19),
(1, 'Brahim Díaz', 'Attaquant', 10),
(1, 'Amine Adli', 'Attaquant', 21),
(1, 'Bilal El Khannouss', 'Milieu', 23);

-- Données initiales pour les Joueurs (Exemple Espagne)
INSERT INTO Joueurs (equipe_id, nom_complet, position, numero_maillot) VALUES
(2, 'Unai Simón', 'Gardien', 1),
(2, 'Dani Carvajal', 'Défenseur', 2),
(2, 'Rodri', 'Milieu', 16),
(2, 'Pedri', 'Milieu', 8),
(2, 'Lamine Yamal', 'Attaquant', 19),
(2, 'Nico Williams', 'Attaquant', 17);
