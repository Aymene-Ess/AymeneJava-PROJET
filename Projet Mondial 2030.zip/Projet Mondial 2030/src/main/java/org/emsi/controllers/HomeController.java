package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.emsi.App;
import org.emsi.dao.MatchDao;
import org.emsi.dao.TicketDao;
import org.emsi.dao.PredictionDao;
import org.emsi.entities.Match;
import org.emsi.entities.Prediction;
import org.emsi.entities.User;
import org.emsi.util.SessionManager;
import javafx.collections.FXCollections;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Contrôleur pour la page d'accueil
 */
public class HomeController {

    @FXML
    private Label welcomeLabel;
    @FXML
    private Label userLabel;
    @FXML
    private Label ticketCountLabel;
    @FXML
    private VBox matchesPreviewContainer;
    @FXML
    private VBox contentArea;

    @FXML
    private ComboBox<String> winnerPredictionCombo;
    @FXML
    private Label predictionStatusLabel;

    private final MatchDao matchDao = new MatchDao();
    private final TicketDao ticketDao = new TicketDao();
    private final PredictionDao predictionDao = new PredictionDao();

    @FXML
    public void initialize() {
        User user = SessionManager.getInstance().getCurrentUser();

        if (user != null) {
            welcomeLabel.setText("Bienvenue, " + user.getUsername() + " ! 👋");
            userLabel.setText(user.getUsername()); // Icon handled by info box

            // Compter les tickets de l'utilisateur
            try {
                int ticketCount = ticketDao.findByUser(user.getId()).size();
                ticketCountLabel.setText(String.valueOf(ticketCount));
            } catch (Exception e) {
                ticketCountLabel.setText("0");
            }
        }

        // Charger les pays pour le pronostic
        if (winnerPredictionCombo != null) {
            winnerPredictionCombo.setItems(FXCollections.observableArrayList(
                    "Maroc 🇲🇦", "Espagne 🇪🇸", "Portugal 🇵🇹",
                    "France 🇫🇷", "Brésil 🇧🇷", "Argentine 🇦🇷",
                    "Allemagne 🇩🇪", "Angleterre 🏴󠁧󠁢󠁥󠁮󠁧󠁿"));
        }

        loadMatchesPreview();
    }

    @FXML
    private void handleTournamentPrediction() {
        String selected = winnerPredictionCombo.getValue();
        if (selected == null) {
            predictionStatusLabel.setText("Veuillez sélectionner un pays !");
            predictionStatusLabel.setStyle("-fx-text-fill: red;");
            predictionStatusLabel.setVisible(true);
            return;
        }

        try {
            User user = SessionManager.getInstance().getCurrentUser();
            Prediction prediction = new Prediction(user, null, selected, "TOURNAMENT");
            predictionDao.save(prediction);

            predictionStatusLabel.setText("✅ Pronostic enregistré ! Bonne chance !");
            predictionStatusLabel.setStyle("-fx-text-fill: #006233;");
            predictionStatusLabel.setVisible(true);
            winnerPredictionCombo.setDisable(true);
        } catch (Exception e) {
            predictionStatusLabel.setText("Erreur lors de l'enregistrement.");
            predictionStatusLabel.setStyle("-fx-text-fill: red;");
            predictionStatusLabel.setVisible(true);
            e.printStackTrace();
        }
    }

    private void loadMatchesPreview() {
        matchesPreviewContainer.getChildren().clear();

        try {
            List<Match> matches = matchDao.findAll();
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy • HH:mm");

            int count = 0;
            for (Match match : matches) {
                if (count >= 2) // Limit to 2 matches as per design
                    break;

                StackPane card = createHorizontalMatchCard(match, sdf);
                matchesPreviewContainer.getChildren().add(card);
                count++;
            }
        } catch (Exception e) {
            Label error = new Label("Impossible de charger les matchs");
            error.setStyle("-fx-text-fill: #C1272D;");
            matchesPreviewContainer.getChildren().add(error);
        }
    }

    private StackPane createHorizontalMatchCard(Match match, SimpleDateFormat sdf) {
        StackPane cardRoot = new StackPane();
        cardRoot.getStyleClass().add("match-card-horizontal");

        // Background Image (Stadium) - Simulated with pattern or color if image not
        // found
        // In a real app we would map stadium names to images
        Region bgOverlay = new Region();
        bgOverlay.setStyle(
                "-fx-background-color: linear-gradient(to right, #0F172A, #1E293B); -fx-background-radius: 16;");

        // Inner Content Overlay
        HBox contentBox = new HBox(20);
        contentBox.getStyleClass().add("match-overlay-dark");
        contentBox.setAlignment(Pos.CENTER_LEFT);

        // Date & Place Section
        VBox datePlaceBox = new VBox(5);
        datePlaceBox.setMinWidth(150);
        Label dateLabel = new Label(sdf.format(match.getMatchDate()));
        dateLabel.setStyle("-fx-text-fill: #F4E08F; -fx-font-weight: bold; -fx-font-size: 14px;");
        Label stadiumLabel = new Label("📍 " + match.getStadium());
        stadiumLabel.getStyleClass().add("match-details-overlay");
        Label cityLabel = new Label(match.getCity());
        cityLabel.setStyle("-fx-text-fill: #94A3B8; -fx-font-size: 13px;");

        datePlaceBox.getChildren().addAll(dateLabel, stadiumLabel, cityLabel);

        // Teams Section (Center)
        VBox teamsBox = new VBox(5);
        teamsBox.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(teamsBox, Priority.ALWAYS);

        Label teamsLabel = new Label(match.getTeamHome() + " vs " + match.getTeamAway());
        teamsLabel.getStyleClass().add("match-title-overlay");

        Label phaseLabel = new Label(match.getMatchPhase());
        phaseLabel.setStyle(
                "-fx-text-fill: #38BDF8; -fx-font-weight: bold; -fx-text-transform: uppercase; -fx-font-size: 12px; -fx-background-color: rgba(56,189,248,0.1); -fx-padding: 3 8; -fx-background-radius: 4;");

        teamsBox.getChildren().addAll(teamsLabel, phaseLabel);

        // Buttons Section (Right)
        VBox buttonsBox = new VBox(10);
        buttonsBox.setAlignment(Pos.CENTER_RIGHT);

        Button buyBtn = new Button("Acheter Ticket");
        buyBtn.getStyleClass().add("btn-overlay-buy");
        buyBtn.setOnAction(e -> navigateToPurchase(match.getId()));

        Button detailsBtn = new Button("Détails");
        detailsBtn.getStyleClass().add("btn-overlay-details");
        detailsBtn.setOnAction(e -> navigateToMatchDetails(match.getId()));

        buttonsBox.getChildren().addAll(buyBtn, detailsBtn);

        contentBox.getChildren().addAll(datePlaceBox, teamsBox, buttonsBox);

        cardRoot.getChildren().addAll(bgOverlay, contentBox);
        return cardRoot;
    }

    private void navigateToPurchase(Integer matchId) {
        try {
            PurchaseController.setSelectedMatchId(matchId);
            App.setRoot("views/purchase");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void navigateToMatchDetails(Integer matchId) {
        try {
            MatchDetailsController.setMatchId(matchId);
            App.setRoot("views/match_details");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void showHome() throws IOException {
        App.setRoot("views/home");
    }

    @FXML
    private void showMatches() throws IOException {
        App.setRoot("views/matches");
    }

    @FXML
    private void showMyTickets() throws IOException {
        App.setRoot("views/my-tickets");
    }

    @FXML
    private void showResale() throws IOException {
        App.setRoot("views/resale");
    }

    @FXML
    private void handleLogout() throws IOException {
        SessionManager.getInstance().logout();
        App.setRoot("views/login");
    }
}
