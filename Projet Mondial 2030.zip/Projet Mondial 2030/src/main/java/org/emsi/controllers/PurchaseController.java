package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.emsi.App;
import org.emsi.dao.MatchDao;
import org.emsi.dao.TicketDao;
import org.emsi.entities.Match;
import org.emsi.entities.Ticket;
import org.emsi.entities.Zone;
import org.emsi.dao.PredictionDao;
import org.emsi.entities.Match;
import org.emsi.entities.Prediction;
import org.emsi.entities.Ticket;
import org.emsi.entities.Zone;
import org.emsi.util.SessionManager;

import java.io.IOException;
import java.text.SimpleDateFormat;

/**
 * Contrôleur pour l'achat de tickets
 */
public class PurchaseController {

    @FXML
    private VBox matchInfoBox;
    @FXML
    private Label matchTeamsLabel;
    @FXML
    private Label matchDetailsLabel;
    @FXML
    private Label matchDateLabel;
    @FXML
    private HBox zonesContainer;
    @FXML
    private VBox summaryBox;
    @FXML
    private Label summaryZone;
    @FXML
    private Label summaryPrice;
    @FXML
    private VBox paymentBox;
    @FXML
    private RadioButton cardPayment;
    @FXML
    private RadioButton paypalPayment;
    @FXML
    private Button confirmBtn;
    @FXML
    private VBox successBox;
    @FXML
    private Label successMessage;
    @FXML
    private Label errorLabel;

    @FXML
    private VBox cardDetailsBox;
    @FXML
    private TextField cardNumberField;
    @FXML
    private TextField cardExpiryField;
    @FXML
    private TextField cardCvvField;

    @FXML
    private TextField guestNameField;
    @FXML
    private TextField guestCinField;

    @FXML
    private VBox ticketPreviewBox;
    @FXML
    private Label previewMatchLabel;
    @FXML
    private Label previewNameLabel;
    @FXML
    private Label previewCinLabel;
    @FXML
    private Label previewZoneLabel;

    @FXML
    private VBox predictionBox;
    @FXML
    private RadioButton predHome;
    @FXML
    private RadioButton predDraw;
    @FXML
    private RadioButton predAway;
    private ToggleGroup predictionGroup;

    @FXML
    private VBox paypalDetailsBox;
    @FXML
    private TextField paypalEmailField;
    @FXML
    private PasswordField paypalPasswordField;

    private static Integer selectedMatchId;
    private Zone selectedZone;
    private ToggleGroup paymentGroup;

    private final MatchDao matchDao = new MatchDao();
    private final TicketDao ticketDao = new TicketDao();
    private final PredictionDao predictionDao = new PredictionDao();

    public static void setSelectedMatchId(Integer matchId) {
        selectedMatchId = matchId;
    }

    @FXML
    public void initialize() {
        errorLabel.setText("");

        // Groupe pour les boutons radio de paiement
        paymentGroup = new ToggleGroup();
        cardPayment.setToggleGroup(paymentGroup);
        paypalPayment.setToggleGroup(paymentGroup);
        cardPayment.setSelected(true);

        // Groupe pour les pronostics
        predictionGroup = new ToggleGroup();
        predHome.setToggleGroup(predictionGroup);
        predDraw.setToggleGroup(predictionGroup);
        predAway.setToggleGroup(predictionGroup);

        // Listener pour paiement (idem)
        paymentGroup.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == cardPayment) {
                cardDetailsBox.setVisible(true);
                cardDetailsBox.setManaged(true);
                paypalDetailsBox.setVisible(false);
                paypalDetailsBox.setManaged(false);
            } else if (newVal == paypalPayment) {
                cardDetailsBox.setVisible(false);
                cardDetailsBox.setManaged(false);
                paypalDetailsBox.setVisible(true);
                paypalDetailsBox.setManaged(true);
            }
        });

        // Listeners pour l'aperçu du ticket
        guestNameField.textProperty().addListener((obs, oldVal, newVal) -> {
            previewNameLabel.setText("Nom: " + (newVal.isEmpty() ? "-" : newVal));
        });

        guestCinField.textProperty().addListener((obs, oldVal, newVal) -> {
            previewCinLabel.setText("CIN: " + (newVal.isEmpty() ? "-" : newVal));
        });

        // Initial state
        cardDetailsBox.setVisible(true);
        cardDetailsBox.setManaged(true);

        if (selectedMatchId != null) {
            loadMatchDetails();
        } else {
            showError("Aucun match sélectionné");
        }
    }

    private void loadMatchDetails() {
        try {
            Match match = matchDao.findById(selectedMatchId);

            if (match == null) {
                showError("Match non trouvé");
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("EEEE dd MMMM yyyy à HH:mm");

            matchTeamsLabel.setText(match.getTeamHome() + " vs " + match.getTeamAway());
            matchDetailsLabel.setText("📍 " + match.getStadium() + ", " + match.getCity());
            matchDateLabel.setText("📅 " + sdf.format(match.getMatchDate()));

            // Update Preview
            previewMatchLabel.setText(match.getTeamHome() + " vs " + match.getTeamAway());

            // Update Prediction labels
            predHome.setText("Victoire " + match.getTeamHome());
            predAway.setText("Victoire " + match.getTeamAway());

            displayZones(match);
        } catch (Exception e) {
            showError("Erreur lors du chargement du match");
            e.printStackTrace();
        }
    }

    private void displayZones(Match match) {
        zonesContainer.getChildren().clear();

        for (Zone zone : match.getZones()) {
            VBox zoneCard = createZoneCard(zone);
            zonesContainer.getChildren().add(zoneCard);
        }
    }

    private VBox createZoneCard(Zone zone) {
        VBox card = new VBox(10);
        card.setAlignment(Pos.CENTER);
        card.setPrefWidth(200);
        card.getStyleClass().add("zone-card-gold");

        if (!zone.hasAvailableSeats()) {
            card.setStyle("-fx-opacity: 0.5;"); // Simple dimming for sold out
        }

        Label categoryLabel = new Label(zone.getCategoryName());
        categoryLabel.getStyleClass().add("zone-category-gold");

        // Icône selon la catégorie
        String icon = switch (zone.getCategoryName()) {
            case "VIP" -> "👑";
            case "CAT1" -> "⭐";
            default -> "🎫";
        };
        Label iconLabel = new Label(icon);
        iconLabel.setStyle("-fx-font-size: 40px; -fx-text-fill: #FFD700;"); // Force Gold for emojis if possible/font

        Label priceLabel = new Label(zone.getPrice() + " MAD");
        priceLabel.getStyleClass().add("zone-price-gold");

        Label seatsLabel = new Label(zone.getAvailableSeats() + " places disponibles");
        seatsLabel.getStyleClass().add("zone-seats-gold");

        Button selectBtn = new Button(zone.hasAvailableSeats() ? "Sélectionner" : "Complet");
        selectBtn.getStyleClass().add(zone.hasAvailableSeats() ? "btn-gold-select" : "btn-disabled");
        selectBtn.setDisable(!zone.hasAvailableSeats());
        selectBtn.setOnAction(e -> selectZone(zone));

        card.getChildren().addAll(iconLabel, categoryLabel, priceLabel, seatsLabel, selectBtn);
        return card;
    }

    private void selectZone(Zone zone) {
        selectedZone = zone;

        // Afficher le récapitulatif
        summaryZone.setText("Zone: " + zone.getCategoryName());
        summaryPrice.setText("Prix: " + zone.getPrice() + " MAD");

        // Update Preview
        previewZoneLabel.setText("Zone: " + zone.getCategoryName() + " (" + zone.getPrice() + " MAD)");

        summaryBox.setVisible(true);
        summaryBox.setManaged(true);

        // Afficher Gamification et Paiement
        predictionBox.setVisible(true);
        predictionBox.setManaged(true);

        paymentBox.setVisible(true);
        paymentBox.setManaged(true);
        confirmBtn.setVisible(true);
        confirmBtn.setManaged(true);

        // Masquer le message d'erreur
        errorLabel.setText("");
    }

    @FXML
    private void handlePurchase() {
        if (selectedZone == null) {
            showError("Veuillez sélectionner une zone");
            return;
        }

        if (paymentGroup.getSelectedToggle() == null) {
            showError("Veuillez choisir une méthode de paiement");
            return;
        }

        // Validation des champs
        String guestName = guestNameField.getText().trim();
        String guestCin = guestCinField.getText().trim();

        if (guestName.isEmpty() || guestCin.isEmpty()) {
            showError("Veuillez remplir le nom et le CIN du visiteur");
            return;
        }

        if (paymentGroup.getSelectedToggle() == cardPayment) {
            if (cardNumberField.getText().isEmpty() || cardExpiryField.getText().isEmpty()
                    || cardCvvField.getText().isEmpty()) {
                showError("Veuillez remplir les détails de la carte");
                return;
            }
        } else {
            if (paypalEmailField.getText().isEmpty() || paypalPasswordField.getText().isEmpty()) {
                showError("Veuillez remplir les identifiants PayPal");
                return;
            }
        }

        try {
            Ticket ticket = ticketDao.purchaseTicket(
                    SessionManager.getInstance().getCurrentUser(),
                    selectedZone, guestName, guestCin);

            if (ticket != null) {
                // Succès
                successMessage.setText("Votre ticket a été généré avec succès !\n" +
                        "Match: " + ticket.getZone().getMatch().getDisplayName() + "\n" +
                        "Zone: " + ticket.getZone().getCategoryName() + "\n" +
                        "Code QR: " + ticket.getUuidQrcode().substring(0, 8) + "...");

                // Masquer les éléments d'achat
                matchInfoBox.setVisible(false);
                matchInfoBox.setManaged(false);
                zonesContainer.setVisible(false);
                zonesContainer.setManaged(false);
                summaryBox.setVisible(false);
                summaryBox.setManaged(false);
                paymentBox.setVisible(false);
                paymentBox.setManaged(false);
                confirmBtn.setVisible(false);
                confirmBtn.setManaged(false);

                // Afficher le succès
                successBox.setVisible(true);
                successBox.setManaged(true);

                // Sauvegarder le pronostic si fait
                if (predictionGroup.getSelectedToggle() != null) {
                    savePrediction();
                }
            } else {
                showError("Achat impossible. La zone est peut-être complète.");
            }
        } catch (Exception e) {
            showError("Erreur lors de l'achat: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void goToMyTickets() throws IOException {
        App.setRoot("views/my-tickets");
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("views/matches");
    }

    private void showError(String message) {
        errorLabel.setText(message);
    }

    private void savePrediction() {
        try {
            RadioButton selected = (RadioButton) predictionGroup.getSelectedToggle();
            String predictionVal = selected.getText(); // "Victoire XXX", "Match Nul", etc.

            // Simplification: extraire juste le nom ou garder le texte complet
            Match match = matchDao.findById(selectedMatchId);

            Prediction prediction = new Prediction(
                    SessionManager.getInstance().getCurrentUser(),
                    match,
                    predictionVal,
                    "MATCH");

            predictionDao.save(prediction);
            System.out.println("Pronostic sauvegardé: " + predictionVal);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
