package org.emsi.controllers;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import org.emsi.App;
import org.emsi.dao.EquipeDao;
import org.emsi.dao.MatchDao;
import org.emsi.dao.StadeDao;
import org.emsi.dao.TicketDao;
import org.emsi.dao.UserDao;
import org.emsi.entities.*;
import org.emsi.util.SessionManager;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AdminController {

    // Views
    @FXML
    private VBox matchesView;
    @FXML
    private VBox stadesView;
    @FXML
    private VBox equipesView;
    @FXML
    private VBox usersView;
    @FXML
    private VBox ticketsView;

    // Matches Table
    @FXML
    private TableView<Match> matchesTable;
    @FXML
    private TableColumn<Match, String> colTeams;
    @FXML
    private TableColumn<Match, String> colDate;
    @FXML
    private TableColumn<Match, String> colStadium;
    @FXML
    private TableColumn<Match, Integer> colTicketsSold;
    @FXML
    private TableColumn<Match, Integer> colTicketsRem;
    @FXML
    private TableColumn<Match, Void> colActions;

    // Stades Table
    @FXML
    private TableView<Stade> stadesTable;
    @FXML
    private TableColumn<Stade, String> colStadeName;
    @FXML
    private TableColumn<Stade, String> colStadeCity;
    @FXML
    private TableColumn<Stade, Integer> colStadeCapacity;
    @FXML
    private TableColumn<Stade, Float> colStadeDistance;
    @FXML
    private TableColumn<Stade, Void> colStadeActions;

    // Equipes Table
    @FXML
    private TableView<Equipe> equipesTable;
    @FXML
    private TableColumn<Equipe, String> colEquipeName;
    @FXML
    private TableColumn<Equipe, String> colEquipeFlag;
    @FXML
    private TableColumn<Equipe, String> colEquipeGroup;
    @FXML
    private TableColumn<Equipe, String> colEquipeConfed;
    @FXML
    private TableColumn<Equipe, Void> colEquipeActions;

    // Users Table
    @FXML
    private TableView<User> usersTable;
    @FXML
    private TableColumn<User, Integer> colUserId;
    @FXML
    private TableColumn<User, String> colUsername;
    @FXML
    private TableColumn<User, String> colUserEmail;
    @FXML
    private TableColumn<User, String> colUserRole;
    @FXML
    private TableColumn<User, Void> colUserActions;

    // Tickets Table
    @FXML
    private TableView<Ticket> ticketsTable;
    @FXML
    private TableColumn<Ticket, Integer> colTicketId;
    @FXML
    private TableColumn<Ticket, String> colTicketUser;
    @FXML
    private TableColumn<Ticket, String> colTicketMatch;
    @FXML
    private TableColumn<Ticket, String> colTicketZone;
    @FXML
    private TableColumn<Ticket, String> colTicketStatus;
    @FXML
    private TableColumn<Ticket, Void> colTicketActions;

    // Forms
    @FXML
    private VBox matchForm;
    @FXML
    private Label formTitle;
    @FXML
    private ComboBox<String> homeTeamCombo;
    @FXML
    private ComboBox<String> awayTeamCombo;
    @FXML
    private ComboBox<String> stadiumCombo;
    @FXML
    private DatePicker matchDatePicker;
    @FXML
    private TextField matchTimeField;

    @FXML
    private VBox stadeForm;
    @FXML
    private Label stadeFormTitle;
    @FXML
    private TextField stadeNameField;
    @FXML
    private TextField stadeCityField;
    @FXML
    private TextField stadeCapacityField;
    @FXML
    private TextField stadeDistanceField;

    @FXML
    private VBox equipeForm;
    @FXML
    private Label equipeFormTitle;
    @FXML
    private TextField equipeNameField;
    @FXML
    private TextField equipeFlagField;
    @FXML
    private TextField equipeGroupField;
    @FXML
    private TextField equipeConfedField;

    // DAOs
    private final MatchDao matchDao = new MatchDao();
    private final TicketDao ticketDao = new TicketDao();
    private final EquipeDao equipeDao = new EquipeDao();
    private final StadeDao stadeDao = new StadeDao();
    private final UserDao userDao = new UserDao();

    private Match currentMatch = null;
    private Stade currentStade = null;
    private Equipe currentEquipe = null;

    @FXML
    private Label adminUserLabel;

    @FXML
    public void initialize() {
        // Initialize User Label
        if (adminUserLabel != null && SessionManager.getInstance().getCurrentUser() != null) {
            adminUserLabel.setText(SessionManager.getInstance().getCurrentUser().getUsername());
        }

        setupMatchesTable();
        // Check if other tables exist in FXML before setup
        if (stadesTable != null)
            setupStadesTable();
        if (equipesTable != null)
            setupEquipesTable();
        if (usersTable != null)
            setupUsersTable();
        if (ticketsTable != null)
            setupTicketsTable();

        initDummyData(); // Populate if empty
        loadFormData();
        showMatches();
    }

    private void initDummyData() {
        if (equipeDao.findAll().isEmpty()) {
            System.out.println("Initializing Dummy Equipes...");
            Equipe ma = new Equipe();
            ma.setNomPays("Maroc");
            ma.setDrapeauUrl("https://upload.wikimedia.org/wikipedia/commons/2/2c/Flag_of_Morocco.svg");
            ma.setGroupe("F");
            ma.setConfederation("CAF");
            equipeDao.save(ma);

            Equipe es = new Equipe();
            es.setNomPays("Espagne");
            es.setDrapeauUrl("https://upload.wikimedia.org/wikipedia/commons/9/9a/Flag_of_Spain.svg");
            es.setGroupe("B");
            es.setConfederation("UEFA");
            equipeDao.save(es);

            Equipe pt = new Equipe();
            pt.setNomPays("Portugal");
            pt.setDrapeauUrl("https://upload.wikimedia.org/wikipedia/commons/5/5c/Flag_of_Portugal.svg");
            pt.setGroupe("H");
            pt.setConfederation("UEFA");
            equipeDao.save(pt);
        }
    }

    private void loadFormData() {
        // Load Teams
        List<Equipe> equipes = equipeDao.findAll();
        List<String> teamNames = new ArrayList<>();
        if (equipes != null) {
            for (Equipe e : equipes)
                teamNames.add(e.getNomPays());
        }
        homeTeamCombo.setItems(FXCollections.observableArrayList(teamNames));
        awayTeamCombo.setItems(FXCollections.observableArrayList(teamNames));

        // Load Stadiums
        List<Stade> stades = stadeDao.findAll();
        List<String> stadeNames = new ArrayList<>();
        if (stades != null) {
            for (Stade s : stades)
                stadeNames.add(s.getNomStade());
        }
        stadiumCombo.setItems(FXCollections.observableArrayList(stadeNames));
    }

    // --- Table Setups ---

    private void setupMatchesTable() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        if (colTeams != null)
            colTeams.setCellValueFactory(cell -> new SimpleStringProperty(
                    cell.getValue().getTeamHome() + " vs " + cell.getValue().getTeamAway()));
        if (colDate != null)
            colDate.setCellValueFactory(cell -> new SimpleStringProperty(sdf.format(cell.getValue().getMatchDate())));
        if (colStadium != null)
            colStadium.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getStadium()));

        if (colTicketsSold != null)
            colTicketsSold.setCellValueFactory(cell -> {
                Match m = cell.getValue();
                int sold = 0;
                if (m.getZones() != null) {
                    for (Zone z : m.getZones())
                        sold += (z.getCapacity() - z.getAvailableSeats());
                }
                return new SimpleObjectProperty<>(sold);
            });

        if (colTicketsRem != null)
            colTicketsRem.setCellValueFactory(cell -> {
                Match m = cell.getValue();
                int rem = 0;
                if (m.getZones() != null) {
                    for (Zone z : m.getZones())
                        rem += z.getAvailableSeats();
                }
                return new SimpleObjectProperty<>(rem);
            });

        if (colActions != null)
            addActionsColumn(colActions, "Match");
        loadMatches();
    }

    private void setupStadesTable() {
        if (colStadeName != null)
            colStadeName.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getNomStade()));
        if (colStadeCity != null)
            colStadeCity.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getVille()));
        if (colStadeCapacity != null)
            colStadeCapacity.setCellValueFactory(cell -> new SimpleObjectProperty<>(cell.getValue().getCapacite()));
        if (colStadeDistance != null)
            colStadeDistance.setCellValueFactory(
                    cell -> new SimpleObjectProperty<>(cell.getValue().getDistanceCentreVilleKm()));

        if (colStadeActions != null)
            addActionsColumn(colStadeActions, "Stade");
        loadStades();
    }

    private void setupEquipesTable() {
        if (colEquipeName != null)
            colEquipeName.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getNomPays()));
        if (colEquipeFlag != null)
            colEquipeFlag.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getDrapeauUrl()));
        if (colEquipeGroup != null)
            colEquipeGroup.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getGroupe()));
        if (colEquipeConfed != null)
            colEquipeConfed.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getConfederation()));

        if (colEquipeActions != null)
            addActionsColumn(colEquipeActions, "Equipe");
        loadEquipes();
    }

    private void setupUsersTable() {
        if (colUserId != null)
            colUserId.setCellValueFactory(cell -> new SimpleObjectProperty<>(cell.getValue().getId()));
        if (colUsername != null)
            colUsername.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getUsername()));
        if (colUserEmail != null)
            colUserEmail.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getEmail()));
        if (colUserRole != null)
            colUserRole.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getRole()));

        // User Action (Delete Only)
        if (colUserActions != null) {
            Callback<TableColumn<User, Void>, TableCell<User, Void>> cellFactory = new Callback<>() {
                @Override
                public TableCell<User, Void> call(final TableColumn<User, Void> param) {
                    return new TableCell<>() {
                        private final Button btnDelete = new Button("🗑️");
                        private final HBox pane = new HBox(5, btnDelete);

                        {
                            btnDelete.getStyleClass().add("btn-action-delete");
                            btnDelete.setTooltip(new Tooltip("Supprimer Utilisateur"));
                            btnDelete.setOnAction(event -> {
                                User user = getTableView().getItems().get(getIndex());
                                handleDeleteUser(user);
                            });
                        }

                        @Override
                        public void updateItem(Void item, boolean empty) {
                            super.updateItem(item, empty);
                            setGraphic(empty ? null : pane);
                        }
                    };
                }
            };
            colUserActions.setCellFactory(cellFactory);
        }
        loadUsers();
    }

    private void setupTicketsTable() {
        if (colTicketId != null)
            colTicketId.setCellValueFactory(cell -> new SimpleObjectProperty<>(cell.getValue().getId()));
        if (colTicketUser != null)
            colTicketUser
                    .setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getUser().getUsername()));
        if (colTicketMatch != null)
            colTicketMatch.setCellValueFactory(
                    cell -> new SimpleStringProperty(cell.getValue().getZone().getMatch().getDisplayName()));
        if (colTicketZone != null)
            colTicketZone
                    .setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getZone().getCategoryName()));
        if (colTicketStatus != null)
            colTicketStatus.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getStatus()));

        // Ticket Actions (Cancel)
        if (colTicketActions != null) {
            Callback<TableColumn<Ticket, Void>, TableCell<Ticket, Void>> cellFactory = new Callback<>() {
                @Override
                public TableCell<Ticket, Void> call(final TableColumn<Ticket, Void> param) {
                    return new TableCell<>() {
                        private final Button btnCancel = new Button("🚫");
                        private final HBox pane = new HBox(5, btnCancel);

                        {
                            btnCancel.getStyleClass().add("btn-action-delete");
                            btnCancel.setTooltip(new Tooltip("Annuler Ticket"));
                            btnCancel.setOnAction(event -> {
                                Ticket ticket = getTableView().getItems().get(getIndex());
                                handleCancelTicket(ticket);
                            });
                        }

                        @Override
                        public void updateItem(Void item, boolean empty) {
                            super.updateItem(item, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                Ticket t = getTableView().getItems().get(getIndex());
                                if (t != null && "ACTIF".equals(t.getStatus())) {
                                    setGraphic(pane);
                                } else {
                                    setGraphic(null);
                                }
                            }
                        }
                    };
                }
            };
            colTicketActions.setCellFactory(cellFactory);
        }
        loadTickets();
    }

    private <T> void addActionsColumn(TableColumn<T, Void> column, String type) {
        Callback<TableColumn<T, Void>, TableCell<T, Void>> cellFactory = new Callback<>() {
            @Override
            public TableCell<T, Void> call(final TableColumn<T, Void> param) {
                return new TableCell<>() {
                    private final Button btnEdit = new Button("✏️");
                    private final Button btnDelete = new Button("🗑️");
                    private final HBox pane = new HBox(10, btnEdit, btnDelete);

                    {
                        btnEdit.getStyleClass().add("btn-action-edit");
                        btnEdit.setTooltip(new Tooltip("Modifier"));
                        btnEdit.setOnAction(event -> {
                            T item = getTableView().getItems().get(getIndex());
                            if (type.equals("Match"))
                                showEditMatchForm((Match) item);
                            else if (type.equals("Stade"))
                                showEditStadeForm((Stade) item);
                            else if (type.equals("Equipe"))
                                showEditEquipeForm((Equipe) item);
                        });

                        btnDelete.getStyleClass().add("btn-action-delete");
                        btnDelete.setTooltip(new Tooltip("Supprimer"));
                        btnDelete.setOnAction(event -> {
                            T item = getTableView().getItems().get(getIndex());
                            if (type.equals("Match"))
                                handleDeleteMatch((Match) item);
                            else if (type.equals("Stade"))
                                handleDeleteStade((Stade) item);
                            else if (type.equals("Equipe"))
                                handleDeleteEquipe((Equipe) item);
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        setGraphic(empty ? null : pane);
                    }
                };
            }
        };
        column.setCellFactory(cellFactory);
    }

    // --- Load Data ---
    private void loadMatches() {
        if (matchesTable != null)
            matchesTable.getItems().setAll(matchDao.findAll());
    }

    private void loadStades() {
        if (stadesTable != null)
            stadesTable.getItems().setAll(stadeDao.findAll());
    }

    private void loadEquipes() {
        if (equipesTable != null)
            equipesTable.getItems().setAll(equipeDao.findAll());
    }

    private void loadUsers() {
        if (usersTable != null)
            usersTable.getItems().setAll(userDao.findAll());
    }

    private void loadTickets() {
        if (ticketsTable != null)
            ticketsTable.getItems().setAll(ticketDao.findAll());
    }

    // --- Handlers & Forms ---

    // MATCH
    @FXML
    private void showAddMatchForm() {
        currentMatch = null;
        formTitle.setText("Nouveau Match");
        matchForm.setVisible(true);
        matchForm.setManaged(true);
        matchesView.setVisible(false);
    }

    private void showEditMatchForm(Match match) {
        currentMatch = match;
        formTitle.setText("Modifier Match");
        homeTeamCombo.setValue(match.getTeamHome());
        awayTeamCombo.setValue(match.getTeamAway());
        stadiumCombo.setValue(match.getStadium());
        LocalDateTime dateTime = match.getMatchDate().toLocalDateTime();
        matchDatePicker.setValue(dateTime.toLocalDate());
        matchTimeField.setText(dateTime.toLocalTime().toString().substring(0, 5));
        matchForm.setVisible(true);
        matchForm.setManaged(true);
        matchesView.setVisible(false);
    }

    @FXML
    private void hideMatchForm() {
        matchForm.setVisible(false);
        matchForm.setManaged(false);
        matchesView.setVisible(true);
    }

    @FXML
    private void handleSaveMatch() {
        try {
            String home = homeTeamCombo.getValue();
            String away = awayTeamCombo.getValue();
            String stadiumName = stadiumCombo.getValue();
            LocalDate date = matchDatePicker.getValue();
            String timeStr = matchTimeField.getText();

            if (home == null || away == null || stadiumName == null || date == null || timeStr.isEmpty())
                return;

            LocalTime time = LocalTime.parse(timeStr);
            LocalDateTime dt = LocalDateTime.of(date, time);
            Timestamp timestamp = Timestamp.valueOf(dt);
            Stade stade = stadeDao.findByName(stadiumName);
            String city = (stade != null) ? stade.getVille() : "Unknown";

            if (currentMatch == null) {
                Match match = new Match();
                match.setTeamHome(home);
                match.setTeamAway(away);
                match.setStadium(stadiumName);
                match.setCity(city);
                match.setMatchDate(timestamp);
                Set<Zone> zones = new HashSet<>();
                zones.add(new Zone(match, "Catégorie 1", new BigDecimal("200.00"), 100));
                zones.add(new Zone(match, "Catégorie 2", new BigDecimal("100.00"), 200));
                zones.add(new Zone(match, "Catégorie 3", new BigDecimal("50.00"), 300));
                match.setZones(zones);
                matchDao.save(match);
            } else {
                currentMatch.setTeamHome(home);
                currentMatch.setTeamAway(away);
                currentMatch.setStadium(stadiumName);
                currentMatch.setCity(city);
                currentMatch.setMatchDate(timestamp);
                matchDao.update(currentMatch);
            }
            hideMatchForm();
            loadMatches();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleDeleteMatch(Match m) {
        matchDao.delete(m);
        loadMatches();
    }

    // STADE
    @FXML
    private void showAddStadeForm() {
        currentStade = null;
        stadeFormTitle.setText("Nouveau Stade");
        stadeForm.setVisible(true);
        stadeForm.setManaged(true);
        stadesView.setVisible(false);
    }

    private void showEditStadeForm(Stade s) {
        currentStade = s;
        stadeFormTitle.setText("Modifier Stade");
        stadeNameField.setText(s.getNomStade());
        stadeCityField.setText(s.getVille());
        stadeCapacityField.setText(String.valueOf(s.getCapacite()));
        stadeDistanceField.setText(String.valueOf(s.getDistanceCentreVilleKm()));
        stadeForm.setVisible(true);
        stadeForm.setManaged(true);
        stadesView.setVisible(false);
    }

    @FXML
    private void hideStadeForm() {
        stadeForm.setVisible(false);
        stadeForm.setManaged(false);
        stadesView.setVisible(true);
    }

    @FXML
    private void handleSaveStade() {
        try {
            Stade s = (currentStade == null) ? new Stade() : currentStade;
            s.setNomStade(stadeNameField.getText());
            s.setVille(stadeCityField.getText());
            s.setCapacite(Integer.parseInt(stadeCapacityField.getText()));
            s.setDistanceCentreVilleKm(Float.parseFloat(stadeDistanceField.getText()));

            if (currentStade == null)
                stadeDao.save(s);
            else
                stadeDao.update(s);
            hideStadeForm();
            loadStades();
            loadFormData(); // reload combo
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleDeleteStade(Stade s) {
        stadeDao.delete(s);
        loadStades();
        loadFormData();
    }

    // EQUIPE
    @FXML
    private void showAddEquipeForm() {
        currentEquipe = null;
        equipeFormTitle.setText("Nouvelle Équipe");
        equipeForm.setVisible(true);
        equipeForm.setManaged(true);
        equipesView.setVisible(false);
    }

    private void showEditEquipeForm(Equipe e) {
        currentEquipe = e;
        equipeFormTitle.setText("Modifier Équipe");
        equipeNameField.setText(e.getNomPays());
        equipeFlagField.setText(e.getDrapeauUrl());
        equipeGroupField.setText(e.getGroupe());
        equipeConfedField.setText(e.getConfederation());
        equipeForm.setVisible(true);
        equipeForm.setManaged(true);
        equipesView.setVisible(false);
    }

    @FXML
    private void hideEquipeForm() {
        equipeForm.setVisible(false);
        equipeForm.setManaged(false);
        equipesView.setVisible(true);
    }

    @FXML
    private void handleSaveEquipe() {
        try {
            Equipe e = (currentEquipe == null) ? new Equipe() : currentEquipe;
            e.setNomPays(equipeNameField.getText());
            e.setDrapeauUrl(equipeFlagField.getText());
            e.setGroupe(equipeGroupField.getText());
            e.setConfederation(equipeConfedField.getText());
            if (currentEquipe == null)
                equipeDao.save(e);
            else
                equipeDao.update(e);
            hideEquipeForm();
            loadEquipes();
            loadFormData();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void handleDeleteEquipe(Equipe e) {
        equipeDao.delete(e);
        loadEquipes();
        loadFormData();
    }

    // USER & TICKET
    private void handleDeleteUser(User u) {
        userDao.delete(u);
        loadUsers();
    }

    private void handleCancelTicket(Ticket t) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Annulation Ticket");
        alert.setHeaderText("Annuler ce ticket ?");
        alert.setContentText("Cela supprimera le ticket et libérera la place.");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                ticketDao.delete(t);
                loadTickets();
                loadMatches(); // Update sold counts
            }
        });
    }

    // Navigation
    private void hideAllViews() {
        matchesView.setVisible(false);
        matchesView.setManaged(false);
        if (stadesView != null) {
            stadesView.setVisible(false);
            stadesView.setManaged(false);
        }
        if (equipesView != null) {
            equipesView.setVisible(false);
            equipesView.setManaged(false);
        }
        if (usersView != null) {
            usersView.setVisible(false);
            usersView.setManaged(false);
        }
        ticketsView.setVisible(false);
        ticketsView.setManaged(false);
        matchForm.setVisible(false);
        matchForm.setManaged(false);
        if (stadeForm != null) {
            stadeForm.setVisible(false);
            stadeForm.setManaged(false);
        }
        if (equipeForm != null) {
            equipeForm.setVisible(false);
            equipeForm.setManaged(false);
        }
    }

    @FXML
    private void showMatches() {
        hideAllViews();
        matchesView.setVisible(true);
        matchesView.setManaged(true);
    }

    @FXML
    private void showStades() {
        hideAllViews();
        if (stadesView != null) {
            stadesView.setVisible(true);
            stadesView.setManaged(true);
        }
    }

    @FXML
    private void showEquipes() {
        hideAllViews();
        if (equipesView != null) {
            equipesView.setVisible(true);
            equipesView.setManaged(true);
        }
    }

    @FXML
    private void showUsers() {
        hideAllViews();
        if (usersView != null) {
            usersView.setVisible(true);
            usersView.setManaged(true);
        }
    }

    @FXML
    private void showTickets() {
        hideAllViews();
        ticketsView.setVisible(true);
        ticketsView.setManaged(true);
    }

    @FXML
    private void handleLogout() throws IOException {
        SessionManager.getInstance().logout();
        App.setRoot("views/login");
    }
}
