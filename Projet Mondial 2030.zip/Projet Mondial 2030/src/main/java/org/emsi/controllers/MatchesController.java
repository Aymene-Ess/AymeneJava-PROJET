package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.emsi.App;
import org.emsi.dao.MatchDao;
import org.emsi.entities.Match;
import org.emsi.entities.Zone;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Contrôleur pour la liste des matchs
 */
public class MatchesController {

    @FXML
    private VBox matchesContainer;
    @FXML
    private TextField searchField;

    private final MatchDao matchDao = new MatchDao();
    private List<Match> allMatches;

    @FXML
    public void initialize() {
        loadMatches();

        // Recherche en temps réel
        searchField.textProperty().addListener((obs, oldVal, newVal) -> filterMatches(newVal));
    }

    private void loadMatches() {
        try {
            allMatches = matchDao.findAll();
            displayMatches(allMatches);
        } catch (Exception e) {
            matchesContainer.getChildren().clear();
            Label error = new Label("❌ Erreur: Impossible de charger les matchs. Vérifiez Docker.");
            error.getStyleClass().add("error-label");
            matchesContainer.getChildren().add(error);
        }
    }

    private void displayMatches(List<Match> matches) {
        matchesContainer.getChildren().clear();
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE dd MMMM yyyy à HH:mm");

        if (matches.isEmpty()) {
            Label noMatch = new Label("Aucun match trouvé");
            noMatch.getStyleClass().add("no-results");
            matchesContainer.getChildren().add(noMatch);
            return;
        }

        for (Match match : matches) {
            StackPane card = createMatchRow(match, sdf);
            matchesContainer.getChildren().add(card);
        }
    }

    private StackPane createMatchRow(Match match, SimpleDateFormat sdf) {
        // Container
        StackPane card = new StackPane();
        card.getStyleClass().add("golden-ticket-card");

        // Inner Border Container
        BorderPane inner = new BorderPane();
        inner.getStyleClass().add("golden-border-inner");
        card.getChildren().add(inner);

        // --- LEFT: Match Info ---
        VBox left = new VBox(15);
        left.setAlignment(Pos.CENTER_LEFT);
        left.setPrefWidth(300);

        Label teams = new Label(match.getTeamHome() + "\nvs\n" + match.getTeamAway());
        teams.getStyleClass().add("golden-ticket-match-title");
        teams.setWrapText(true);

        Label loc = new Label("📍 " + match.getCity() + " (" + match.getStadium() + ")");
        loc.getStyleClass().add("golden-ticket-details");

        Label date = new Label("📅 " + sdf.format(match.getMatchDate()));
        date.getStyleClass().add("golden-ticket-details");

        left.getChildren().addAll(teams, loc, date);
        inner.setLeft(left);

        // --- CENTER: Visuals & Zones ---
        VBox center = new VBox(10);
        center.setAlignment(Pos.CENTER);

        Label header = new Label("🏆 Coupe du Monde Maroc 2030 🏆");
        header.getStyleClass().add("golden-ticket-header");

        // Image centrale (Mascotte ou Stade)
        javafx.scene.image.ImageView img = new javafx.scene.image.ImageView();
        try {
            // Fallback to mascot if no specific stadium image
            img.setImage(new javafx.scene.image.Image(
                    getClass().getResourceAsStream("/org/emsi/images/mascot_jallaba.png")));
        } catch (Exception e) {
            // ignore if missing
        }
        img.setFitHeight(100);
        img.setPreserveRatio(true);
        img.setStyle("-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 0);");

        // Zones Boxes
        HBox zonesBox = new HBox(10);
        zonesBox.setAlignment(Pos.CENTER);
        for (Zone zone : match.getZones()) {
            Label zBadge = new Label(zone.getCategoryName() + "\n" + zone.getPrice() + " MAD");
            zBadge.getStyleClass().add("zone-badge-gold");
            zBadge.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
            if (!zone.hasAvailableSeats()) {
                zBadge.setStyle("-fx-opacity: 0.5; -fx-strikethrough: true; -fx-background-color: #ddd;");
            }
            zonesBox.getChildren().add(zBadge);
        }

        center.getChildren().addAll(header, img, zonesBox);
        inner.setCenter(center);

        // --- RIGHT: Action ---
        VBox right = new VBox();
        right.setAlignment(Pos.CENTER_RIGHT);
        right.setPrefWidth(150);

        Button buyBtn = new Button("ACHETER");
        buyBtn.getStyleClass().add("btn-golden-buy");
        buyBtn.setOnAction(e -> navigateToPurchase(match.getId()));

        right.getChildren().add(buyBtn);
        inner.setRight(right);

        return card;
    }

    private void filterMatches(String query) {
        if (query == null || query.isEmpty()) {
            displayMatches(allMatches);
            return;
        }

        String lowerQuery = query.toLowerCase();
        List<Match> filtered = allMatches.stream()
                .filter(m -> m.getTeamHome().toLowerCase().contains(lowerQuery) ||
                        m.getTeamAway().toLowerCase().contains(lowerQuery) ||
                        m.getStadium().toLowerCase().contains(lowerQuery) ||
                        m.getCity().toLowerCase().contains(lowerQuery))
                .toList();

        displayMatches(filtered);
    }

    private void navigateToPurchase(Integer matchId) {
        try {
            PurchaseController.setSelectedMatchId(matchId);
            App.setRoot("views/purchase");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("views/home");
    }
}
