package org.emsi;

import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.emsi.dao.HibernateUtil;

import java.io.IOException;

/**
 * Application principale Mondial 2030 Experience
 */
public class App extends Application {

    private static Stage primaryStage;
    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;

        // Intro Animation
        // Intro Animation
        ImageView trophy = new ImageView();
        try {
            trophy.setImage(new Image(getClass().getResourceAsStream("images/mascot_jallaba.png")));
        } catch (Exception e) {
            System.err.println("Image not found: images/mascot_jallaba.png");
        }
        trophy.setFitHeight(400);
        trophy.setPreserveRatio(true);

        StackPane introRoot = new StackPane(trophy);
        // Style inline pour l'intro
        introRoot.setStyle("-fx-background-color: #1a1a2e;");

        Scene introScene = new Scene(introRoot, 1000, 700);
        stage.setScene(introScene);
        stage.setTitle("🏆 Mondial 2030 Experience - Billetterie Officielle");

        // Icône de l'application
        try {
            stage.getIcons().add(new Image(getClass().getResourceAsStream("images/logo.png")));
        } catch (Exception e) {
            System.out.println("Logo non trouvé, utilisation de l'icône par défaut");
        }

        stage.show();

        // Initialisation des données en background
        new Thread(() -> org.emsi.util.DataSeeder.seed()).start();

        // Animation
        FadeTransition fade = new FadeTransition(Duration.seconds(2.5), trophy);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.setOnFinished(e -> {
            try {
                showLogin();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
        fade.play();
    }

    private void showLogin() throws IOException {
        scene = new Scene(loadFXML("views/login"), 1200, 800);
        scene.getStylesheets().add(getClass().getResource("styles/styles.css").toExternalForm());
        primaryStage.setScene(scene);
    }

    /**
     * Change la vue principale
     */
    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    /**
     * Charge un fichier FXML
     */
    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    /**
     * Retourne le stage principal
     */
    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    @Override
    public void stop() {
        // Fermeture propre de Hibernate
        HibernateUtil.shutdown();
    }

    public static void main(String[] args) {
        launch();
    }
}
