package org.emsi.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entité Ticket - Représente un billet de match
 */
public class Ticket {

    private Integer id;
    private User user;
    private Zone zone;
    private String uuidQrcode;
    private String status; // ACTIF, EN_REVENTE, VENDU, UTILISE
    private Timestamp purchaseDate;
    private BigDecimal resalePrice;

    private String guestName;
    private String guestCin;

    public Ticket() {
        this.uuidQrcode = UUID.randomUUID().toString();
        this.status = "ACTIF";
    }

    public Ticket(User user, Zone zone) {
        this();
        this.user = user;
        this.zone = zone;
    }

    public Ticket(User user, Zone zone, String guestName, String guestCin) {
        this(user, zone);
        this.guestName = guestName;
        this.guestCin = guestCin;
    }

    // Getters et Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Zone getZone() {
        return zone;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }

    public String getUuidQrcode() {
        return uuidQrcode;
    }

    public void setUuidQrcode(String uuidQrcode) {
        this.uuidQrcode = uuidQrcode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(Timestamp purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public BigDecimal getResalePrice() {
        return resalePrice;
    }

    public void setResalePrice(BigDecimal resalePrice) {
        this.resalePrice = resalePrice;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getGuestCin() {
        return guestCin;
    }

    public void setGuestCin(String guestCin) {
        this.guestCin = guestCin;
    }

    // Méthodes métier
    public boolean isActive() {
        return "ACTIF".equals(this.status);
    }

    public boolean isForResale() {
        return "EN_REVENTE".equals(this.status);
    }

    public void putForResale(BigDecimal price) {
        this.status = "EN_REVENTE";
        this.resalePrice = price;
    }

    public void cancelResale() {
        this.status = "ACTIF";
        this.resalePrice = null;
    }

    public void markAsSold() {
        this.status = "VENDU";
    }

    public void markAsUsed() {
        this.status = "UTILISE";
    }

    public Match getMatch() {
        return zone != null ? zone.getMatch() : null;
    }

    @Override
    public String toString() {
        return "Ticket #" + id + " [" + status + "] - " +
                (zone != null ? zone.getMatch().getDisplayName() : "N/A");
    }
}
