package org.emsi.entities;

import java.math.BigDecimal;

/**
 * Entité Zone - Représente une zone de stade (VIP, CAT1, CAT2)
 */
public class Zone {

    private Integer id;
    private Match match;
    private String categoryName; // VIP, CAT1, CAT2
    private BigDecimal price;
    private Integer capacity;
    private Integer availableSeats;

    public Zone() {
    }

    public Zone(Match match, String categoryName, BigDecimal price, Integer capacity) {
        this.match = match;
        this.categoryName = categoryName;
        this.price = price;
        this.capacity = capacity;
        this.availableSeats = capacity;
    }

    // Getters et Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Integer getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(Integer availableSeats) {
        this.availableSeats = availableSeats;
    }

    public boolean hasAvailableSeats() {
        return availableSeats != null && availableSeats > 0;
    }

    public void decrementSeats() {
        if (hasAvailableSeats()) {
            this.availableSeats--;
        }
    }

    public void incrementSeats() {
        if (availableSeats < capacity) {
            this.availableSeats++;
        }
    }

    public String getDisplayName() {
        return categoryName + " - " + price + " MAD";
    }

    @Override
    public String toString() {
        return categoryName + " (" + availableSeats + "/" + capacity + " places) - " + price + " MAD";
    }
}
