package org.emsi.entities;

import javax.persistence.*;

@Entity
@Table(name = "Stades")
public class Stade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nom_stade")
    private String nomStade;

    private String ville;
    private int capacite;

    @Column(name = "distance_centre_ville_km")
    private float distanceCentreVilleKm;

    @Column(name = "photo_url")
    private String photoUrl;

    public Stade() {
    }

    public Stade(String nomStade, String ville, int capacite, float distanceCentreVilleKm, String photoUrl) {
        this.nomStade = nomStade;
        this.ville = ville;
        this.capacite = capacite;
        this.distanceCentreVilleKm = distanceCentreVilleKm;
        this.photoUrl = photoUrl;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomStade() {
        return nomStade;
    }

    public void setNomStade(String nomStade) {
        this.nomStade = nomStade;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public float getDistanceCentreVilleKm() {
        return distanceCentreVilleKm;
    }

    public void setDistanceCentreVilleKm(float distanceCentreVilleKm) {
        this.distanceCentreVilleKm = distanceCentreVilleKm;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }
}
