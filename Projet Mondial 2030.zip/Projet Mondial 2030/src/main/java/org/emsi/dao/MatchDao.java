package org.emsi.dao;

import org.emsi.entities.Match;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

/**
 * DAO pour la gestion des matchs
 */
public class MatchDao {

    /**
     * Liste tous les matchs avec leurs zones
     */
    public List<Match> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Match ORDER BY matchDate", Match.class).list();
        }
    }

    /**
     * Récupère un match par son ID
     */
    public Match findById(Integer id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Match.class, id);
        }
    }

    /**
     * Recherche des matchs par équipe
     */
    public List<Match> findByTeam(String teamName) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Match> query = session.createQuery(
                    "FROM Match WHERE teamHome LIKE :team OR teamAway LIKE :team ORDER BY matchDate",
                    Match.class);
            query.setParameter("team", "%" + teamName + "%");
            return query.list();
        }
    }

    /**
     * Recherche des matchs par stade
     */
    public List<Match> findByStadium(String stadium) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Match> query = session.createQuery(
                    "FROM Match WHERE stadium LIKE :stadium ORDER BY matchDate",
                    Match.class);
            query.setParameter("stadium", "%" + stadium + "%");
            return query.list();
        }
    }

    /**
     * Recherche des matchs par ville
     */
    public List<Match> findByCity(String city) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Match> query = session.createQuery(
                    "FROM Match WHERE city = :city ORDER BY matchDate",
                    Match.class);
            query.setParameter("city", city);
            return query.list();
        }
    }

    /**
     * Liste les matchs à venir
     */
    public List<Match> findUpcoming() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Match> query = session.createQuery(
                    "FROM Match WHERE matchDate > CURRENT_TIMESTAMP ORDER BY matchDate",
                    Match.class);
            return query.list();
        }
    }

    /**
     * Sauvegarde un nouveau match
     */
    public void save(Match match) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(match);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Met à jour un match
     */
    public void update(Match match) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(match);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Supprime un match
     */
    public void delete(Match match) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.delete(match);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }
}
