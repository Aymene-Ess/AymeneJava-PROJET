package org.emsi.dao;

import org.emsi.entities.Joueur;
import org.hibernate.Session;

import java.util.List;

public class JoueurDao {

    public List<Joueur> findByEquipe(Long equipeId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Joueur WHERE equipe.id = :equipeId", Joueur.class)
                    .setParameter("equipeId", equipeId)
                    .list();
        }
    }
}
