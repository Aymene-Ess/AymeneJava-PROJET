package org.emsi.test;

import org.emsi.dao.UserDao;
import org.emsi.entities.User;
import org.emsi.util.DataSeeder;

public class TestLogin {
    public static void main(String[] args) {
        try {
            java.io.PrintStream fileOut = new java.io.PrintStream("diagnostic.log");
            System.setOut(fileOut);
            System.setErr(fileOut);
        } catch (Exception e) {
        }
        System.out.println("=== DIAGNOSTIC START ===");
        try {
            // Test 1: Database Connection Probing
            System.out.println("Test 1: Probing Passwords...");
            String[] passwords = { "root123", "", "root", "password", "123456", "admin" };
            String correctPassword = null;

            for (String pwd : passwords) {
                System.out.println("Trying password: '" + pwd + "'...");
                try {
                    java.sql.DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/mondial2030?useSSL=false&serverTimezone=UTC&createDatabaseIfNotExist=true&allowPublicKeyRetrieval=true",
                            "root", pwd);
                    System.out.println("SUCCESS: Password found: '" + pwd + "'");
                    correctPassword = pwd;
                    break;
                } catch (java.sql.SQLException ex) {
                    System.out.println("Failed: " + ex.getMessage());
                }
            }

            if (correctPassword != null) {
                System.out.println("RECOMMENDATION: Update hibernate.cfg.xml with password: '" + correctPassword + "'");
            } else {
                System.out.println("FAILURE: No common password worked.");
            }

            // Only proceed if we found it (this test script is ephemeral)
            if (correctPassword == null)
                return;

            // Test 2: Data Seeder
            System.out.println("\nTest 2: Running DataSeeder...");
            DataSeeder.seed();
            System.out.println("DataSeeder completed (check console for internal errors if any).");

            UserDao userDao = new UserDao();

            // Test 3: Authenticate Admin
            System.out.println("\nTest 3: Authenticating 'admin'...");
            User admin = userDao.authenticate("admin", "admin123");
            if (admin != null) {
                System.out.println("SUCCESS: Admin authenticated. Role: " + admin.getRole());
            } else {
                System.out.println("FAILURE: Admin not found or password mismatch.");
                // Try to find if user exists at all
                User user = userDao.findByUsername("admin");
                if (user != null) {
                    System.out.println("DEBUG: User 'admin' exists but password might be wrong.");
                    System.out.println("DEBUG: DB Password: " + user.getPassword());
                } else {
                    System.out.println("DEBUG: User 'admin' DOES NOT EXIST in database.");
                }
            }

            // Test 4: Registration
            System.out.println("\nTest 4: Testing Registration...");
            String testUser = "testuser_" + System.currentTimeMillis();
            if (userDao.usernameExists(testUser)) {
                System.out.println("Unexpected: " + testUser + " already exists.");
            } else {
                try {
                    User registered = userDao.register(testUser, "pass123", "test@test.com");
                    System.out.println(
                            "SUCCESS: Registered " + registered.getUsername() + " (ID: " + registered.getId() + ")");

                    User authTest = userDao.authenticate(testUser, "pass123");
                    if (authTest != null) {
                        System.out.println("SUCCESS: Authenticated new user immediately.");
                    } else {
                        System.out.println("FAILURE: Could not authenticate new user.");
                    }
                } catch (Exception e) {
                    System.out.println("FAILURE: Registration threw exception:");
                    e.printStackTrace();
                }
            }

        } catch (Throwable e) {
            System.err.println("CRITICAL FAILURE:");
            e.printStackTrace();
        }
        System.out.println("=== DIAGNOSTIC END ===");
        System.exit(0);
    }
}
