package org.emsi.util;

import org.emsi.dao.UserDao;
import org.emsi.entities.User;

public class VerifyAdmin {
    public static void main(String[] args) {
        // Ensure Hibernate is initialized if needed, but DAO does it via HibernateUtil
        try {
            UserDao dao = new UserDao();
            User admin = dao.findByUsername("admin");

            if (admin != null) {
                System.out.println("Found user: " + admin.getUsername());
                System.out.println("Role: " + admin.getRole());
                if (admin.isAdmin()) {
                    System.out.println("VERIFICATION SUCCESS: Admin user exists and has correct role.");
                } else {
                    System.out.println("VERIFICATION FAILED: Role is not ADMIN.");
                }
            } else {
                System.out.println("VERIFICATION FAILED: Admin user not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            org.emsi.dao.HibernateUtil.shutdown();
        }
    }
}
