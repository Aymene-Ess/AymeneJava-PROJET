package org.emsi.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ListUsersJdbc {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3307/mondial2030?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user = "root"; // Using root as updated in hibernate.cfg.xml
        String pass = "root123";

        System.out.println("=== COMPTES ENREGISTRÉS ===");
        try (Connection conn = DriverManager.getConnection(url, user, pass);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT username, role, email FROM users")) {

            boolean found = false;
            while (rs.next()) {
                found = true;
                String username = rs.getString("username");
                String role = rs.getString("role");
                String email = rs.getString("email");
                System.out.println(
                        "- User: " + username + " | Role: " + role + " | Email: " + (email != null ? email : "N/A"));
            }

            if (!found) {
                System.out.println("Aucun compte trouvé.");
            }

        } catch (Exception e) {
            System.err.println("Erreur de récupération: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("===========================");
    }
}
