package org.emsi.util;

import org.emsi.dao.HibernateUtil;
import org.emsi.dao.UserDao;
import org.emsi.entities.User;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class DataSeeder {
    public static void seed() {
        UserDao userDao = new UserDao();
        if (!userDao.usernameExists("admin")) {
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Transaction tx = session.beginTransaction();
                User admin = new User("admin", "admin123", "admin@mondial2030.ma", "ADMIN");
                session.save(admin);
                tx.commit();
                System.out.println("Admin user created successfully.");
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    java.io.PrintWriter pw = new java.io.PrintWriter("seeder_error.log");
                    e.printStackTrace(pw);
                    pw.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}
